# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['projeto_python']

package_data = \
{'': ['*']}

install_requires = \
['httpx>=0.22.0,<0.23.0', 'pandas>=1.4.1,<2.0.0']

entry_points = \
{'console_scripts': ['meu-script = projeto_python.cli:cli']}

setup_kwargs = {
    'name': 'projeto-python',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'medeiros-erika',
    'author_email': 'ems.erikamedeiros@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
